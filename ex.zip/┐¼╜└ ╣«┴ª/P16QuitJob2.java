// �κ����� - ���
import java.util.Scanner;

public class P16QuitJob2 {
	static int[] T = new int[16];
	static int[] P = new int[16];
	static int N, max;
	static boolean[] day;
	static void solve(int k, int n, int p){
		if (k == n){
			max = Math.max(max, p);
			return;
		}
		solve(k + 1, n, p);
		if (k + T[k] > n) return;

		for (int i = k; i < k + T[k]; i++)
			if (day[i]) return;
		
		for (int i = k; i < k + T[k]; i++)
			day[i] = true;
		solve(k + 1, n, p + P[k]);
		for (int i = k; i < k + T[k]; i++)
			day[i] = false;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		day = new boolean[N + 1];
		
		for (int i = 1; i <= N; i++)
		{
			T[i] = sc.nextInt();
			P[i] = sc.nextInt();
		}
		max = 0;
		solve(1, N + 1, 0);

		System.out.printf("%d\n", max);
		sc.close();

	}

}
