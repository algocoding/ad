import java.util.Scanner;

/*
S: �۽ű�, O: ���ű�, L: /, R:\, #: ��
----------------------
1
6 3 3   
S..R.O
###...
L....L
..O.##
R..R..
S..S#O
1 1 0
6 1 0
6 4 3
1 6 1
4 3 1
6 6 3
----------------------
 ��> 2
 */
public class Mirror {

	static char[][] map = new char[6][6];
	static int N, M, K; // N: ���� ũ��, M/K: �ۼ��ű� ��
	static class Pos{
		int x, y;
		int dir;
		Pos(int a, int b, int c){
			x = a; y = b; dir = c;
		}
	}
	static Pos[] S = new Pos[5];
	static Pos[] O = new Pos[5];
	static void solve(int k, int n, int visit)
	{
		
	}
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);		
		int T = sc.nextInt();
		for(int tc = 1; tc <= T; tc++)
		{
			N = sc.nextInt();
			M = sc.nextInt();
			K = sc.nextInt();
			
			for(int i = 0; i < N; i++)
			{
				String str = sc.next();
				for(int j = 0; j < N; j++)
					map[i][j] = str.charAt(j);
			}
			
			for(int i = 0; i < M; i++)
			{
				int a = sc.nextInt();
				int b = sc.nextInt();
				int c = sc.nextInt();
				S[i] = new Pos(a, b, c);				
			}
			for(int i = 0; i < K; i++)
			{
				int a = sc.nextInt();
				int b = sc.nextInt();
				int c = sc.nextInt();
				O[i] = new Pos(a, b, c);				
			}
			
			Solve(0, M, 0);
			
		}
		sc.close();
	}

}
